import 'package:flutter/material.dart';

void main() {
  runApp(const TeaChaiApp());
}

class TeaChaiApp extends StatelessWidget {
  const TeaChaiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'TEA CHAI',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF176B3A)),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

class Product {
  final String name;
  double price;
  Product(this.name, this.price);
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final products = <Product>[
    Product('சாதா டீ', 15),
    Product('வடை', 5),
    Product('போண்டா', 5),
    Product('பஜ்ஜி', 5),
  ];

  final Map<String, int> cart = {};
  double salesToday = 0;

  double get total {
    double sum = 0;
    for (final p in products) {
      sum += (cart[p.name] ?? 0) * p.price;
    }
    return sum;
  }

  void add(Product p) => setState(() => cart[p.name] = (cart[p.name] ?? 0) + 1);
  void remove(Product p) => setState(() {
        final q = cart[p.name] ?? 0;
        if (q <= 1) {
          cart.remove(p.name);
        } else {
          cart[p.name] = q - 1;
        }
      });

  void checkout() {
    if (total == 0) return;
    setState(() {
      salesToday += total;
      cart.clear();
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Bill saved successfully')),
    );
  }

  void editPrices() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => PriceListScreen(products: products)),
    );
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF176B3A),
        foregroundColor: Colors.white,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('TEA CHAI', style: TextStyle(fontWeight: FontWeight.bold)),
            Text('Karumandurai • Taste the best tea of the hills',
                style: TextStyle(fontSize: 11)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Price List',
            onPressed: editPrices,
            icon: const Icon(Icons.price_change),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const Icon(Icons.receipt_long, size: 40),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('New Bill',
                            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                        Text('Today Sales: ₹${salesToday.toStringAsFixed(0)}'),
                      ],
                    ),
                  ),
                  Text('₹${total.toStringAsFixed(0)}',
                      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          const Text('☕ TEA & SNACKS',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ...products.map((p) => Card(
                child: ListTile(
                  title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: Text('₹${p.price.toStringAsFixed(0)}'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(onPressed: () => remove(p), icon: const Icon(Icons.remove_circle_outline)),
                      Text('${cart[p.name] ?? 0}', style: const TextStyle(fontSize: 17)),
                      IconButton(onPressed: () => add(p), icon: const Icon(Icons.add_circle)),
                    ],
                  ),
                ),
              )),
          const SizedBox(height: 8),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [const Text('Grand Total', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                      Text('₹${total.toStringAsFixed(0)}', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold))]),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(child: OutlinedButton.icon(
                        onPressed: total == 0 ? null : () => _paymentDialog(),
                        icon: const Icon(Icons.payments),
                        label: const Text('Payment'),
                      )),
                      const SizedBox(width: 10),
                      Expanded(child: FilledButton.icon(
                        onPressed: total == 0 ? null : checkout,
                        icon: const Icon(Icons.receipt),
                        label: const Text('Generate Bill'),
                      )),
                    ],
                  )
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: editPrices,
            icon: const Icon(Icons.edit),
            label: const Text('Edit Price List'),
          ),
        ],
      ),
    );
  }

  void _paymentDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Payment'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(leading: const Icon(Icons.money), title: const Text('Cash'), onTap: () { Navigator.pop(context); checkout(); }),
          ListTile(leading: const Icon(Icons.qr_code_2), title: const Text('UPI'), onTap: () { Navigator.pop(context); checkout(); }),
          ListTile(leading: const Icon(Icons.credit_card), title: const Text('Card'), onTap: () { Navigator.pop(context); checkout(); }),
        ]),
      ),
    );
  }
}

class PriceListScreen extends StatefulWidget {
  final List<Product> products;
  const PriceListScreen({super.key, required this.products});
  @override
  State<PriceListScreen> createState() => _PriceListScreenState();
}

class _PriceListScreenState extends State<PriceListScreen> {
  void edit(Product p) {
    final c = TextEditingController(text: p.price.toStringAsFixed(0));
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('${p.name} விலை மாற்றம்'),
        content: TextField(
          controller: c,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(prefixText: '₹ ', labelText: 'New Price'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(onPressed: () {
            final value = double.tryParse(c.text);
            if (value != null && value >= 0) setState(() => p.price = value);
            Navigator.pop(context);
          }, child: const Text('Save')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Price List')),
    body: ListView(
      padding: const EdgeInsets.all(12),
      children: widget.products.map((p) => Card(
        child: ListTile(
          title: Text(p.name),
          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
            Text('₹${p.price.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.bold)),
            IconButton(onPressed: () => edit(p), icon: const Icon(Icons.edit)),
          ]),
        ),
      )).toList(),
    ),
  );
}
