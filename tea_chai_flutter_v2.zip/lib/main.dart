import 'package:flutter/material.dart';

void main() => runApp(const TeaChaiApp());

class Product {
  String name;
  double price;
  int stock;
  Product(this.name, this.price, {this.stock = 100});
}

class TeaChaiApp extends StatelessWidget {
  const TeaChaiApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'TEA CHAI',
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF176B3A)), useMaterial3: true),
    home: const HomeScreen(),
  );
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final products = <Product>[
    Product('சாதா டீ', 15), Product('வடை', 5),
    Product('போண்டா', 5), Product('பஜ்ஜி', 5),
  ];
  final cart = <String,int>{};
  double sales = 0, expenses = 0, credit = 0;
  bool parcel = false;
  double parcelCharge = 0;

  double get total {
    double x = 0;
    for (final p in products) x += (cart[p.name] ?? 0) * p.price;
    return x + (parcel ? parcelCharge : 0);
  }

  void add(Product p) {
    if ((cart[p.name] ?? 0) >= p.stock) return;
    setState(() => cart[p.name] = (cart[p.name] ?? 0) + 1);
  }
  void remove(Product p) => setState(() {
    final q = cart[p.name] ?? 0;
    if (q <= 1) cart.remove(p.name); else cart[p.name] = q - 1;
  });

  void completeBill(String payment) {
    if (total <= 0) return;
    setState(() { sales += total; cart.clear(); });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Bill saved • $payment • ₹${total.toStringAsFixed(0)}')),
    );
  }

  void payment() {
    showModalBottomSheet(context: context, builder: (_) => SafeArea(
      child: Wrap(children: [
        const ListTile(title: Text('Select Payment', style: TextStyle(fontWeight: FontWeight.bold))),
        ListTile(leading: const Icon(Icons.money), title: const Text('Cash'), onTap: () { Navigator.pop(context); completeBill('Cash'); }),
        ListTile(leading: const Icon(Icons.qr_code_2), title: const Text('UPI'), onTap: () { Navigator.pop(context); completeBill('UPI'); }),
        ListTile(leading: const Icon(Icons.credit_card), title: const Text('Card'), onTap: () { Navigator.pop(context); completeBill('Card'); }),
        ListTile(leading: const Icon(Icons.account_balance_wallet), title: const Text('Credit / கடன்'), onTap: () { Navigator.pop(context); setState(() { credit += total; }); completeBill('Credit'); }),
      ]),
    ));
  }

  Future<void> openExpenses() async {
    final c = TextEditingController();
    await showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('Daily Expense'),
      content: TextField(controller: c, keyboardType: TextInputType.number, decoration: const InputDecoration(prefixText: '₹ ', labelText: 'Amount')),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(onPressed: () { final x = double.tryParse(c.text); if (x != null) setState(() => expenses += x); Navigator.pop(context); }, child: const Text('Save'))],
    ));
  }

  Future<void> openPrices() async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => PriceScreen(products: products)));
    setState(() {});
  }

  void report() => showDialog(context: context, builder: (_) => AlertDialog(
    title: const Text('📊 Daily Sales'),
    content: Text('Sales: ₹${sales.toStringAsFixed(0)}\nExpenses: ₹${expenses.toStringAsFixed(0)}\nNet: ₹${(sales-expenses).toStringAsFixed(0)}\nCustomer Credit: ₹${credit.toStringAsFixed(0)}'),
    actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
  ));

  void settings() => showModalBottomSheet(context: context, builder: (_) => SafeArea(
    child: Wrap(children: [
      const ListTile(title: Text('⚙️ Settings', style: TextStyle(fontWeight: FontWeight.bold))),
      ListTile(leading: const Icon(Icons.lock), title: const Text('Owner PIN'), onTap: () { Navigator.pop(context); _pin(); }),
      ListTile(leading: const Icon(Icons.backup), title: const Text('Backup / Restore'), onTap: () { Navigator.pop(context); _info('Backup', 'Database backup/restore will be connected in the next build.'); }),
      ListTile(leading: const Icon(Icons.print), title: const Text('Printer Settings'), onTap: () { Navigator.pop(context); _info('Printer', 'Bluetooth thermal printer support is planned.'); }),
    ]),
  ));

  void _pin() {
    final c = TextEditingController();
    showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('Owner PIN'),
      content: TextField(controller: c, obscureText: true, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Set / Change PIN')),
      actions: [FilledButton(onPressed: () { Navigator.pop(context); _info('Security', 'PIN option added to the prototype.'); }, child: const Text('Save'))],
    ));
  }

  void _info(String title, String msg) => showDialog(context: context, builder: (_) => AlertDialog(title: Text(title), content: Text(msg), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))]));

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      backgroundColor: const Color(0xFF176B3A), foregroundColor: Colors.white,
      title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('TEA CHAI', style: TextStyle(fontWeight: FontWeight.bold)),
        Text('Karumandurai • Taste the best tea of the hills', style: TextStyle(fontSize: 11)),
      ]),
      actions: [IconButton(onPressed: settings, icon: const Icon(Icons.settings))],
    ),
    body: ListView(padding: const EdgeInsets.all(14), children: [
      Row(children: [
        Expanded(child: _card('Today Sales', '₹${sales.toStringAsFixed(0)}', Icons.point_of_sale)),
        const SizedBox(width: 8),
        Expanded(child: _card('Net', '₹${(sales-expenses).toStringAsFixed(0)}', Icons.analytics)),
      ]),
      const SizedBox(height: 10),
      Card(child: SwitchListTile(
        title: const Text('📦 Parcel', style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(parcel ? 'Parcel mode ON' : 'Shop / Dine-in mode'),
        value: parcel, onChanged: (v) => setState(() => parcel = v),
      )),
      if (parcel) Card(child: ListTile(
        title: const Text('Parcel Charge'),
        trailing: SizedBox(width: 100, child: TextField(
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(prefixText: '₹'),
          onChanged: (v) => setState(() => parcelCharge = double.tryParse(v) ?? 0),
        )),
      )),
      const SizedBox(height: 8),
      const Text('☕ TEA & SNACKS', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      ...products.map((p) => Card(child: ListTile(
        title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text('₹${p.price.toStringAsFixed(0)} • Stock ${p.stock}'),
        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
          IconButton(onPressed: () => remove(p), icon: const Icon(Icons.remove_circle_outline)),
          Text('${cart[p.name] ?? 0}'),
          IconButton(onPressed: () => add(p), icon: const Icon(Icons.add_circle)),
        ]),
      ))),
      Card(child: Padding(padding: const EdgeInsets.all(15), child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('Grand Total', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          Text('₹${total.toStringAsFixed(0)}', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        ]),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: OutlinedButton.icon(onPressed: total == 0 ? null : payment, icon: const Icon(Icons.payments), label: const Text('Payment'))),
          const SizedBox(width: 8),
          Expanded(child: FilledButton.icon(onPressed: total == 0 ? null : () => completeBill('Cash'), icon: const Icon(Icons.receipt), label: const Text('Generate Bill'))),
        ]),
      ]))),
      const SizedBox(height: 8),
      Wrap(spacing: 8, runSpacing: 8, children: [
        OutlinedButton.icon(onPressed: openPrices, icon: const Icon(Icons.price_change), label: const Text('Price List')),
        OutlinedButton.icon(onPressed: openExpenses, icon: const Icon(Icons.money_off), label: const Text('Expenses')),
        OutlinedButton.icon(onPressed: report, icon: const Icon(Icons.bar_chart), label: const Text('Daily Sales')),
        OutlinedButton.icon(onPressed: () => _info('Customer Credit', 'Current credit: ₹${credit.toStringAsFixed(0)}'), icon: const Icon(Icons.people), label: const Text('Credit')),
        OutlinedButton.icon(onPressed: () => _info('Stock', 'Stock quantities are shown beside each item.'), icon: const Icon(Icons.inventory_2), label: const Text('Stock')),
      ]),
    ]),
  );

  Widget _card(String title, String value, IconData icon) => Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Icon(icon), const SizedBox(height: 5), Text(title), Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))
  ])));
}

class PriceScreen extends StatefulWidget {
  final List<Product> products;
  const PriceScreen({super.key, required this.products});
  @override State<PriceScreen> createState() => _PriceScreenState();
}
class _PriceScreenState extends State<PriceScreen> {
  void edit(Product p) {
    final c = TextEditingController(text: p.price.toStringAsFixed(0));
    showDialog(context: context, builder: (_) => AlertDialog(
      title: Text('${p.name} விலை மாற்றம்'),
      content: TextField(controller: c, keyboardType: TextInputType.number, decoration: const InputDecoration(prefixText: '₹ ', labelText: 'New Price')),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(onPressed: () { final x = double.tryParse(c.text); if (x != null) setState(() => p.price = x); Navigator.pop(context); }, child: const Text('Save'))],
    ));
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Price List')),
    body: ListView(padding: const EdgeInsets.all(12), children: widget.products.map((p) => Card(child: ListTile(
      title: Text(p.name), trailing: Row(mainAxisSize: MainAxisSize.min, children: [
        Text('₹${p.price.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.bold)),
        IconButton(onPressed: () => edit(p), icon: const Icon(Icons.edit))
      ])
    ))).toList()),
  );
}
