# TEA CHAI – Karumandurai V2 Prototype

V2 adds:
- Parcel mode and parcel charge
- Cash / UPI / Card / Credit payment choices
- Daily sales, expenses and net calculation
- Customer credit balance
- Basic stock quantities
- Price editing
- Owner PIN settings placeholder
- Backup/restore and thermal-printer settings placeholders

Run:
flutter pub get
flutter run

Note: this is a prototype. Persistent encrypted database, real backup/restore, Bluetooth printing, WhatsApp sharing and production-grade authentication should be added before business deployment.
