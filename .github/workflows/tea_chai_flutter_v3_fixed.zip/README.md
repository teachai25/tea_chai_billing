# TEA CHAI – Karumandurai

Starter Flutter prototype for the tea shop billing app.

## Included
- Home screen
- New bill
- Default menu: சாதா டீ ₹15, வடை ₹5, போண்டா ₹5, பஜ்ஜி ₹5
- Quantity +/-
- Automatic total
- Cash / UPI / Card selection
- Generate bill
- Price List edit screen
- Today sales total (prototype memory only)

## Run
1. Install Flutter SDK and Android Studio.
2. Extract this ZIP.
3. Open the folder in Android Studio or VS Code.
4. Run:
   flutter pub get
   flutter run

This is a prototype. Database, secure login, persistent sales, printer, WhatsApp sharing, parcel, expenses, stock and backup can be added next.
