import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const TeaChaiApp());

class TeaChaiApp extends StatelessWidget {
  const TeaChaiApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'TEA CHAI',
        theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF176B3A)), useMaterial3: true),
        home: const HomeScreen(),
      );
}

class Product {
  final String name;
  double price;
  Product(this.name, this.price);
}

class SavedBill {
  final int number;
  final DateTime date;
  final String payment;
  final Map<String, int> items;
  final double total;
  SavedBill({required this.number, required this.date, required this.payment, required this.items, required this.total});
  Map<String, dynamic> toJson() => {'number': number, 'date': date.toIso8601String(), 'payment': payment, 'items': items, 'total': total};
  factory SavedBill.fromJson(Map<String, dynamic> j) => SavedBill(
        number: j['number'], date: DateTime.parse(j['date']), payment: j['payment'] ?? 'Cash',
        items: Map<String, int>.from((j['items'] as Map).map((k, v) => MapEntry(k.toString(), (v as num).toInt()))), total: (j['total'] as num).toDouble());
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final products = <Product>[Product('சாதா டீ', 15), Product('வடை', 5), Product('போண்டா', 5), Product('பஜ்ஜி', 5)];
  final Map<String, int> cart = {};
  List<SavedBill> bills = [];
  SharedPreferences? prefs;
  bool ready = false;

  double get total => products.fold(0, (s, p) => s + (cart[p.name] ?? 0) * p.price);
  int get itemCount => cart.values.fold(0, (a, b) => a + b);
  double get salesToday {
    final d = DateTime.now();
    return bills.where((b) => b.date.year == d.year && b.date.month == d.month && b.date.day == d.day).fold(0, (s, b) => s + b.total);
  }

  @override void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    prefs = await SharedPreferences.getInstance();
    final saved = prefs!.getString('bills');
    final savedCart = prefs!.getString('current_cart');
    if (saved != null) bills = (jsonDecode(saved) as List).map((e) => SavedBill.fromJson(Map<String, dynamic>.from(e))).toList();
    if (savedCart != null) cart.addAll(Map<String, int>.from((jsonDecode(savedCart) as Map).map((k, v) => MapEntry(k.toString(), (v as num).toInt()))));
    if (prefs!.getString('prices') != null) {
      final m = Map<String, dynamic>.from(jsonDecode(prefs!.getString('prices')!));
      for (final p in products) if (m[p.name] != null) p.price = (m[p.name] as num).toDouble();
    }
    if (mounted) setState(() => ready = true);
  }

  Future<void> _persistCart() async { if (prefs != null) await prefs!.setString('current_cart', jsonEncode(cart)); }
  Future<void> _persistBills() async { if (prefs != null) await prefs!.setString('bills', jsonEncode(bills.map((b) => b.toJson()).toList())); }

  void add(Product p) { setState(() => cart[p.name] = (cart[p.name] ?? 0) + 1); _persistCart(); }
  void remove(Product p) { setState(() { final q = cart[p.name] ?? 0; if (q <= 1) cart.remove(p.name); else cart[p.name] = q - 1; }); _persistCart(); }
  void clearCart() { setState(cart.clear); _persistCart(); }

  Future<void> checkout(String payment) async {
    if (total <= 0) return;
    final bill = SavedBill(number: (bills.isEmpty ? 0 : bills.map((b) => b.number).reduce((a, b) => a > b ? a : b)) + 1,
      date: DateTime.now(), payment: payment, items: Map<String, int>.from(cart), total: total);
    setState(() { bills.insert(0, bill); cart.clear(); });
    await _persistBills(); await _persistCart();
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Bill #${bill.number} saved successfully')));
  }

  Future<void> editPrices() async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => PriceListScreen(products: products, onSave: _savePrices)));
    if (mounted) setState(() {});
  }
  Future<void> _savePrices() async { if (prefs != null) await prefs!.setString('prices', jsonEncode({for (final p in products) p.name: p.price})); }

  Future<void> paymentDialog() async {
    final payment = await showDialog<String>(context: context, builder: (_) => AlertDialog(title: const Text('Payment Method'), content: Column(mainAxisSize: MainAxisSize.min, children: [
      ListTile(leading: const Icon(Icons.money), title: const Text('Cash'), onTap: () => Navigator.pop(context, 'Cash')),
      ListTile(leading: const Icon(Icons.qr_code_2), title: const Text('UPI'), onTap: () => Navigator.pop(context, 'UPI')),
      ListTile(leading: const Icon(Icons.credit_card), title: const Text('Card'), onTap: () => Navigator.pop(context, 'Card')),
    ])));
    if (payment != null) await checkout(payment);
  }

  @override Widget build(BuildContext context) {
    if (!ready) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(backgroundColor: const Color(0xFF176B3A), foregroundColor: Colors.white,
        title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('TEA CHAI', style: TextStyle(fontWeight: FontWeight.bold)), Text('Karumandurai • Taste the best tea of the hills', style: TextStyle(fontSize: 11))]),
        actions: [IconButton(tooltip: 'Bill History', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SalesScreen(bills: bills))), icon: const Icon(Icons.history)), IconButton(onPressed: editPrices, icon: const Icon(Icons.price_change))]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [const Icon(Icons.receipt_long, size: 40), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('New Bill', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), Text('Today Sales: ₹${salesToday.toStringAsFixed(0)}'), Text('${bills.length} saved bills') ])), Text('₹${total.toStringAsFixed(0)}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))]))),
        const SizedBox(height: 12), const Text('☕ TEA & SNACKS', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)), const SizedBox(height: 8),
        ...products.map((p) => Card(child: ListTile(title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w600)), subtitle: Text('₹${p.price.toStringAsFixed(0)}'), trailing: Row(mainAxisSize: MainAxisSize.min, children: [IconButton(onPressed: () => remove(p), icon: const Icon(Icons.remove_circle_outline)), Text('${cart[p.name] ?? 0}', style: const TextStyle(fontSize: 17)), IconButton(onPressed: () => add(p), icon: const Icon(Icons.add_circle))])))),
        const SizedBox(height: 8),
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Items: $itemCount', style: const TextStyle(fontSize: 17)), Text('Grand Total ₹${total.toStringAsFixed(0)}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))]), const SizedBox(height: 12), Row(children: [Expanded(child: OutlinedButton.icon(onPressed: total == 0 ? null : clearCart, icon: const Icon(Icons.delete_outline), label: const Text('Clear'))), const SizedBox(width: 8), Expanded(child: FilledButton.icon(onPressed: total == 0 ? null : paymentDialog, icon: const Icon(Icons.receipt), label: const Text('Save Bill')))])])),
        const SizedBox(height: 12), OutlinedButton.icon(onPressed: editPrices, icon: const Icon(Icons.edit), label: const Text('Edit Price List')),
      ]),
    );
  }
}

class SalesScreen extends StatelessWidget {
  final List<SavedBill> bills;
  const SalesScreen({super.key, required this.bills});
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Saved Bills / Sales')), body: bills.isEmpty ? const Center(child: Text('No saved bills')) : ListView.builder(padding: const EdgeInsets.all(12), itemCount: bills.length, itemBuilder: (_, i) { final b = bills[i]; return Card(child: ExpansionTile(title: Text('Bill #${b.number}  •  ₹${b.total.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text('${b.date.day.toString().padLeft(2,'0')}-${b.date.month.toString().padLeft(2,'0')}-${b.date.year}  ${b.payment}'), children: b.items.entries.map((e) => ListTile(dense: true, title: Text(e.key), trailing: Text('x${e.value}'))).toList())); }));
}

class PriceListScreen extends StatefulWidget {
  final List<Product> products; final Future<void> Function() onSave;
  const PriceListScreen({super.key, required this.products, required this.onSave});
  @override State<PriceListScreen> createState() => _PriceListScreenState();
}
class _PriceListScreenState extends State<PriceListScreen> {
  void edit(Product p) { final c = TextEditingController(text: p.price.toStringAsFixed(0)); showDialog(context: context, builder: (_) => AlertDialog(title: Text('${p.name} விலை மாற்றம்'), content: TextField(controller: c, keyboardType: TextInputType.number, decoration: const InputDecoration(prefixText: '₹ ', labelText: 'New Price')), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')), FilledButton(onPressed: () async { final value = double.tryParse(c.text); if (value != null && value >= 0) { setState(() => p.price = value); await widget.onSave(); } if (mounted) Navigator.pop(context); }, child: const Text('Save'))])); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Price List')), body: ListView(padding: const EdgeInsets.all(12), children: widget.products.map((p) => Card(child: ListTile(title: Text(p.name), trailing: Row(mainAxisSize: MainAxisSize.min, children: [Text('₹${p.price.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.bold)), IconButton(onPressed: () => edit(p), icon: const Icon(Icons.edit))])))).toList()));
}
